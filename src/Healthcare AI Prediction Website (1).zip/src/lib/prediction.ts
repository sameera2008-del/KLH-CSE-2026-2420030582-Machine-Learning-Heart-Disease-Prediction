export interface PatientData {
  age: string;
  sex: string;
  chestPain: string;
  restingBP: string;
  cholesterol: string;
  fastingBS: string;
  restingECG: string;
  maxHR: string;
  exerciseAngina: string;
  stDepression: string;
  numVessels: string;
  thal: string;
}

export interface FeatureContribution {
  name: string;
  shapValue: number;
  displayValue: string;
}

export interface PredictionResult {
  isHighRisk: boolean;
  riskProbability: number;
  confidence: number;
  features: FeatureContribution[];
  limeFeatures: FeatureContribution[];
  summary: string;
  patientData: PatientData;
}

const CHEST_PAIN_LABELS: Record<string, string> = {
  '0': 'Typical Angina',
  '1': 'Atypical Angina',
  '2': 'Non-anginal Pain',
  '3': 'Asymptomatic',
};

const ECG_LABELS: Record<string, string> = {
  '0': 'Normal',
  '1': 'ST-T Abnormality',
  '2': 'LV Hypertrophy',
};

const THAL_LABELS: Record<string, string> = {
  '0': 'Normal',
  '1': 'Fixed Defect',
  '2': 'Reversible Defect',
};

export function predictHeartDisease(data: PatientData): PredictionResult {
  const age = parseInt(data.age);
  const bp = parseInt(data.restingBP);
  const chol = parseInt(data.cholesterol);
  const hr = parseInt(data.maxHR);
  const st = parseFloat(data.stDepression);
  const vessels = parseInt(data.numVessels);

  const contribs: Array<{ name: string; raw: number; displayValue: string }> = [];

  // Chest pain (strongest predictor)
  const cpVals: Record<string, number> = { '0': -0.18, '1': 0.08, '2': 0.2, '3': 0.44 };
  contribs.push({ name: 'Chest Pain Type', raw: cpVals[data.chestPain] ?? 0, displayValue: CHEST_PAIN_LABELS[data.chestPain] ?? '-' });

  // Thalassemia
  const thalVals: Record<string, number> = { '0': -0.1, '1': 0.22, '2': 0.38 };
  contribs.push({ name: 'Thalassemia', raw: thalVals[data.thal] ?? 0, displayValue: THAL_LABELS[data.thal] ?? '-' });

  // Max heart rate (lower = higher risk)
  const hrRaw = hr < 100 ? 0.38 : hr < 130 ? 0.2 : hr < 150 ? 0.06 : -0.14;
  contribs.push({ name: 'Maximum Heart Rate', raw: hrRaw, displayValue: `${hr} bpm` });

  // Exercise-induced angina
  const anginaRaw = data.exerciseAngina === '1' ? 0.32 : -0.09;
  contribs.push({ name: 'Exercise-Induced Angina', raw: anginaRaw, displayValue: data.exerciseAngina === '1' ? 'Yes' : 'No' });

  // Number of major vessels
  const vesselVals: Record<number, number> = { 0: -0.1, 1: 0.16, 2: 0.3, 3: 0.4 };
  contribs.push({ name: 'Number of Vessels', raw: vesselVals[vessels] ?? 0, displayValue: `${vessels} vessel(s)` });

  // ST depression
  const stRaw = st > 3 ? 0.35 : st > 2 ? 0.24 : st > 1 ? 0.14 : st > 0 ? 0.06 : -0.06;
  contribs.push({ name: 'ST Depression', raw: stRaw, displayValue: st.toFixed(1) });

  // Age
  const ageRaw = age > 65 ? 0.32 : age > 55 ? 0.2 : age > 45 ? 0.1 : -0.06;
  contribs.push({ name: 'Age', raw: ageRaw, displayValue: `${age} years` });

  // Cholesterol
  const cholRaw = chol > 300 ? 0.26 : chol > 240 ? 0.16 : chol > 200 ? 0.06 : -0.04;
  contribs.push({ name: 'Cholesterol', raw: cholRaw, displayValue: `${chol} mg/dl` });

  // Resting BP
  const bpRaw = bp > 160 ? 0.24 : bp > 140 ? 0.15 : bp > 120 ? 0.05 : -0.04;
  contribs.push({ name: 'Resting Blood Pressure', raw: bpRaw, displayValue: `${bp} mmHg` });

  // Sex
  const sexRaw = data.sex === '1' ? 0.16 : -0.1;
  contribs.push({ name: 'Sex', raw: sexRaw, displayValue: data.sex === '1' ? 'Male' : 'Female' });

  // Fasting blood sugar
  const fbsRaw = data.fastingBS === '1' ? 0.1 : -0.04;
  contribs.push({ name: 'Fasting Blood Sugar', raw: fbsRaw, displayValue: data.fastingBS === '1' ? '> 120 mg/dl' : '≤ 120 mg/dl' });

  // Resting ECG
  const ecgVals: Record<string, number> = { '0': -0.05, '1': 0.14, '2': 0.08 };
  contribs.push({ name: 'Resting ECG', raw: ecgVals[data.restingECG] ?? 0, displayValue: ECG_LABELS[data.restingECG] ?? '-' });

  const total = contribs.reduce((s, c) => s + c.raw, 0);

  // Normalize to probability range [0.03, 0.97]
  const minPoss = -0.95;
  const maxPoss = 3.05;
  const norm = (total - minPoss) / (maxPoss - minPoss);
  const riskProbability = Math.round(Math.min(97, Math.max(3, norm * 100)));
  const isHighRisk = riskProbability >= 50;
  const confidence = isHighRisk ? riskProbability : 100 - riskProbability;

  const sorted = [...contribs].sort((a, b) => Math.abs(b.raw) - Math.abs(a.raw));

  const features: FeatureContribution[] = sorted.map((c) => ({
    name: c.name,
    shapValue: parseFloat(c.raw.toFixed(3)),
    displayValue: c.displayValue,
  }));

  const limeFeatures = features.slice(0, 6);

  const top3 = features.slice(0, 3).map((f) => f.name.toLowerCase());
  const summary = isHighRisk
    ? `The model predicts a HIGH risk of heart disease with ${confidence}% confidence. The prediction is primarily driven by ${top3[0]}, ${top3[1]}, and ${top3[2]}. Immediate clinical evaluation is strongly recommended.`
    : `The model predicts a LOW risk of heart disease with ${confidence}% confidence. The patient's ${top3[0]} and ${top3[1]} are the dominant factors supporting this outcome. Regular monitoring is still advisable.`;

  return { isHighRisk, riskProbability, confidence, features, limeFeatures, summary, patientData: data };
}

// ── Personalized summary & recommendations ───────────────────────────────────

export interface HumanFactor {
  name: string;
  label: string;
  value: string;
  direction: 'risk' | 'protective';
  reason: string;
  shapValue: number;
}

export interface PersonalizedSummary {
  riskFactors: HumanFactor[];
  protectiveFactors: HumanFactor[];
  simpleExplanation: string;
  shapLimeAgreement: { count: number; total: number };
}

export interface RiskRecommendation {
  factor: string;
  shortLabel: string;
  severity: 'high' | 'moderate' | 'informational';
  context: string;
  suggestion: string;
  iconType: 'heart' | 'activity' | 'lab' | 'age' | 'ecg' | 'vessel';
}

function humanLabel(feature: FeatureContribution, data: PatientData): string {
  switch (feature.name) {
    case 'Chest Pain Type': {
      const m: Record<string, string> = { '0': 'Typical Angina Pattern', '1': 'Atypical Chest Pain', '2': 'Non-anginal Chest Pain', '3': 'Asymptomatic Chest Pain' };
      return m[data.chestPain] ?? 'Chest Pain Type';
    }
    case 'Cholesterol': return parseInt(data.cholesterol) > 240 ? 'High Serum Cholesterol' : 'Serum Cholesterol';
    case 'Resting Blood Pressure': return parseInt(data.restingBP) > 140 ? 'Elevated Blood Pressure' : 'Resting Blood Pressure';
    case 'Age': return `Age (${data.age} years)`;
    case 'Maximum Heart Rate': return parseInt(data.maxHR) < 130 ? `Low Max Heart Rate (${data.maxHR} bpm)` : `Max Heart Rate (${data.maxHR} bpm)`;
    case 'Exercise-Induced Angina': return data.exerciseAngina === '1' ? 'Exercise-Induced Angina (Present)' : 'No Exercise Angina';
    case 'ST Depression': return `ST Depression (${parseFloat(data.stDepression).toFixed(1)})`;
    case 'Number of Vessels': return parseInt(data.numVessels) > 0 ? `${data.numVessels} Major Vessel(s) Affected` : 'No Major Vessels Affected';
    case 'Thalassemia': {
      const m: Record<string, string> = { '0': 'Normal Thalassemia', '1': 'Fixed Defect', '2': 'Reversible Defect' };
      return m[data.thal] ?? 'Thalassemia Result';
    }
    case 'Sex': return data.sex === '1' ? 'Male Sex' : 'Female Sex';
    case 'Fasting Blood Sugar': return data.fastingBS === '1' ? 'Elevated Fasting Blood Sugar' : 'Normal Fasting Blood Sugar';
    case 'Resting ECG': {
      const m: Record<string, string> = { '0': 'Normal Resting ECG', '1': 'ST-T Wave Abnormality', '2': 'LV Hypertrophy on ECG' };
      return m[data.restingECG] ?? 'Resting ECG';
    }
    default: return feature.name;
  }
}

function factorReason(feature: FeatureContribution, data: PatientData): string {
  const isRisk = feature.shapValue > 0;
  switch (feature.name) {
    case 'Chest Pain Type':
      return data.chestPain === '3' ? 'Asymptomatic presentation is paradoxically associated with higher risk.' : isRisk ? 'This chest pain pattern elevates the predicted risk.' : 'This chest pain pattern reduces the predicted risk.';
    case 'Cholesterol':
      return parseInt(data.cholesterol) > 240 ? 'Above the 240 mg/dl threshold — a recognised cardiovascular risk marker.' : isRisk ? 'Contributes to elevated risk prediction.' : 'Within a lower-risk cholesterol range.';
    case 'Resting Blood Pressure':
      return parseInt(data.restingBP) > 140 ? 'Above 140 mmHg, indicative of hypertension.' : isRisk ? 'Contributes to elevated risk.' : 'Within an acceptable blood pressure range.';
    case 'Age':
      return `At ${data.age} years, age is a recognised non-modifiable cardiovascular risk factor.`;
    case 'Maximum Heart Rate':
      return parseInt(data.maxHR) < 130 ? 'Lower exercise capacity is associated with higher predicted risk.' : 'Good exercise capacity acts as a protective indicator.';
    case 'Exercise-Induced Angina':
      return data.exerciseAngina === '1' ? 'Presence of exercise angina is a significant risk indicator.' : 'Absence of exercise angina supports a lower-risk outcome.';
    case 'ST Depression':
      return parseFloat(data.stDepression) > 1 ? 'Elevated ST depression is a clinically significant marker.' : 'Minimal ST changes — a reassuring finding.';
    case 'Number of Vessels':
      return parseInt(data.numVessels) > 0 ? `${data.numVessels} affected vessel(s) suggests more extensive coronary involvement.` : 'No vessels affected — a protective sign.';
    case 'Thalassemia':
      return data.thal === '2' ? 'Reversible defect suggests active ischaemia.' : data.thal === '1' ? 'Fixed defect may indicate prior cardiac event.' : 'Normal thalassemia result supports a lower-risk outcome.';
    case 'Sex':
      return data.sex === '1' ? 'Male sex is statistically associated with higher coronary artery disease risk.' : 'Female sex is associated with a lower baseline risk in this dataset.';
    case 'Fasting Blood Sugar':
      return data.fastingBS === '1' ? 'Elevated fasting blood sugar may indicate diabetes, a known risk factor.' : 'Normal fasting blood sugar is a protective indicator.';
    case 'Resting ECG':
      return data.restingECG !== '0' ? 'ECG abnormalities are associated with underlying cardiac changes.' : 'Normal resting ECG is a reassuring finding.';
    default:
      return isRisk ? 'Contributes to elevated risk prediction.' : 'Contributes toward lower risk prediction.';
  }
}

export function generateSummary(result: PredictionResult): PersonalizedSummary {
  const { features, limeFeatures, patientData } = result;

  const riskFactors: HumanFactor[] = features
    .filter((f) => f.shapValue > 0.05)
    .slice(0, 5)
    .map((f) => ({ name: f.name, label: humanLabel(f, patientData), value: f.displayValue, direction: 'risk', reason: factorReason(f, patientData), shapValue: f.shapValue }));

  const protectiveFactors: HumanFactor[] = features
    .filter((f) => f.shapValue < -0.04)
    .slice(0, 3)
    .map((f) => ({ name: f.name, label: humanLabel(f, patientData), value: f.displayValue, direction: 'protective', reason: factorReason(f, patientData), shapValue: f.shapValue }));

  const top3 = riskFactors.slice(0, 3).map((f) => f.label.toLowerCase());
  const simpleExplanation = top3.length > 0
    ? `The prediction was primarily influenced by ${top3.join(', ')}.`
    : 'The model found no strongly dominant risk factors in this patient profile.';

  const shapTop5 = features.slice(0, 5).map((f) => f.name);
  const limeTop5 = limeFeatures.slice(0, 5).map((f) => f.name);
  const commonCount = shapTop5.filter((n) => limeTop5.includes(n)).length;

  return { riskFactors, protectiveFactors, simpleExplanation, shapLimeAgreement: { count: commonCount, total: 5 } };
}

export function generateRecommendations(result: PredictionResult): RiskRecommendation[] {
  const { features, patientData } = result;
  const recs: RiskRecommendation[] = [];

  for (const f of features.filter((x) => x.shapValue > 0).slice(0, 6)) {
    const rec = buildRecommendation(f.name, patientData);
    if (rec) recs.push(rec);
  }

  return recs.slice(0, 5);
}

function buildRecommendation(name: string, data: PatientData): RiskRecommendation | null {
  switch (name) {
    case 'Cholesterol': {
      const v = parseInt(data.cholesterol);
      if (v <= 200) return null;
      return { factor: 'Serum Cholesterol', shortLabel: v > 240 ? 'High Cholesterol' : 'Borderline Cholesterol', severity: v > 240 ? 'high' : 'moderate', context: `Cholesterol of ${v} mg/dl was identified as a contributing factor to this prediction.`, suggestion: 'Consider discussing cholesterol management and appropriate lipid testing with a healthcare professional.', iconType: 'lab' };
    }
    case 'Resting Blood Pressure': {
      const v = parseInt(data.restingBP);
      if (v <= 120) return null;
      return { factor: 'Blood Pressure', shortLabel: v > 140 ? 'Elevated Blood Pressure' : 'Borderline Blood Pressure', severity: v > 140 ? 'high' : 'moderate', context: `A resting blood pressure of ${v} mmHg was identified as a contributing factor.`, suggestion: 'Monitor blood pressure regularly. Discuss persistent elevated readings with a healthcare professional.', iconType: 'heart' };
    }
    case 'Chest Pain Type': {
      if (data.chestPain === '0' || data.chestPain === '1') return null;
      const labels: Record<string, string> = { '2': 'Non-anginal Chest Pain', '3': 'Asymptomatic Chest Pain' };
      return { factor: 'Chest Pain Type', shortLabel: labels[data.chestPain] ?? 'Chest Pain Pattern', severity: data.chestPain === '3' ? 'high' : 'moderate', context: 'Chest pain pattern was identified as a significant factor in the model\'s prediction.', suggestion: 'Chest pain patterns — including asymptomatic presentations — should be discussed with a qualified healthcare professional for proper evaluation.', iconType: 'heart' };
    }
    case 'Age': {
      const v = parseInt(data.age);
      if (v < 45) return null;
      return { factor: 'Age', shortLabel: `Age ${v} — Non-modifiable Factor`, severity: 'informational', context: `Age is a non-modifiable cardiovascular risk factor. At ${v} years, the model identified age as a contributing influence.`, suggestion: 'Regular cardiovascular health screening may be appropriate at this age. Consult a healthcare professional for personalised guidance.', iconType: 'age' };
    }
    case 'Maximum Heart Rate': {
      const v = parseInt(data.maxHR);
      if (v >= 150) return null;
      return { factor: 'Maximum Heart Rate', shortLabel: `Low Max HR (${v} bpm)`, severity: v < 120 ? 'high' : 'moderate', context: `A maximum heart rate of ${v} bpm during exercise was identified as a contributing factor.`, suggestion: 'Exercise tolerance and cardiovascular fitness are worth discussing with a healthcare professional, particularly in the context of cardiac evaluation.', iconType: 'activity' };
    }
    case 'Exercise-Induced Angina': {
      if (data.exerciseAngina !== '1') return null;
      return { factor: 'Exercise-Induced Angina', shortLabel: 'Exercise-Induced Chest Pain', severity: 'high', context: 'Chest discomfort occurring during physical activity was identified as a significant contributing factor.', suggestion: 'Chest discomfort associated with exercise should be discussed promptly with a qualified healthcare professional.', iconType: 'activity' };
    }
    case 'ST Depression': {
      const v = parseFloat(data.stDepression);
      if (v <= 0.5) return null;
      return { factor: 'ST Depression', shortLabel: `ST Depression (${v.toFixed(1)})`, severity: v > 2 ? 'high' : 'moderate', context: `ST depression of ${v.toFixed(1)} was identified as a contributing factor. Values above 2.0 are generally considered clinically significant.`, suggestion: 'ST-segment changes are important clinical findings. These should be reviewed with a cardiologist or healthcare professional.', iconType: 'ecg' };
    }
    case 'Number of Vessels': {
      const v = parseInt(data.numVessels);
      if (v === 0) return null;
      return { factor: 'Major Vessels Affected', shortLabel: `${v} Major Vessel(s) Affected`, severity: v >= 2 ? 'high' : 'moderate', context: `${v} major blood vessel(s) were identified as affected on fluoroscopy imaging, and contributed to the prediction.`, suggestion: 'The number of affected major vessels is an important clinical finding. Discuss these results with a cardiologist.', iconType: 'vessel' };
    }
    case 'Thalassemia': {
      if (data.thal === '0') return null;
      const labels: Record<string, string> = { '1': 'Fixed Defect', '2': 'Reversible Defect' };
      return { factor: 'Thalassemia Result', shortLabel: labels[data.thal] ?? 'Thalassemia Defect', severity: data.thal === '2' ? 'high' : 'moderate', context: `A ${(labels[data.thal] ?? 'defect').toLowerCase()} on the nuclear stress test was identified as a contributing factor.`, suggestion: 'Nuclear stress test findings should be reviewed and discussed with a cardiologist or cardiac specialist.', iconType: 'ecg' };
    }
    default: return null;
  }
}

// ── Multi-model comparison simulation ────────────────────────────────────────

export interface PerModelPrediction {
  name: string;
  shortName: string;
  isHighRisk: boolean;
  probability: number; // 0–1
  color: string;
  isProposed: boolean;
  ensembleWeight?: number; // weight this model receives in the ensemble (0–1)
}

// Simulated feature importance multipliers per model type.
// Feature order (12 values):
//   [0] chestPain  [1] thal      [2] maxHR   [3] exerciseAngina  [4] numVessels
//   [5] stDep      [6] age       [7] chol    [8] restingBP       [9] sex
//   [10] fastingBS [11] restingECG
const BASELINE_CONFIGS = [
  {
    name: 'Logistic Regression', shortName: 'LR', color: '#6366f1',
    // Balanced linear model — all features contribute proportionally
    mults: [1.00, 0.90, 0.85, 1.05, 0.95, 1.05, 0.80, 0.90, 0.85, 0.70, 0.60, 0.75],
    weight: 0.15,
  },
  {
    name: 'Decision Tree', shortName: 'DT', color: '#f59e0b',
    // Tree splits on most discriminative features; downweights continuous ones
    mults: [1.35, 1.40, 0.55, 1.25, 1.50, 1.10, 0.50, 0.35, 0.45, 0.25, 0.20, 0.55],
    weight: 0.10,
  },
  {
    name: 'Naive Bayes', shortName: 'NB', color: '#ec4899',
    // Independence assumption; slightly underweights high-correlation features
    mults: [0.88, 0.82, 0.95, 1.00, 0.88, 0.90, 0.72, 0.82, 0.78, 0.62, 0.52, 0.68],
    weight: 0.10,
  },
  {
    name: 'Random Forest', shortName: 'RF', color: '#3b82f6',
    // Ensemble of trees: balanced, elevated on top-importance features
    mults: [1.10, 1.15, 0.90, 1.05, 1.20, 1.00, 0.85, 0.95, 0.90, 0.75, 0.65, 0.80],
    weight: 0.35,
  },
  {
    name: 'Support Vector Machine', shortName: 'SVM', color: '#8b5cf6',
    // Margin-based: emphasises boundary-defining features
    mults: [1.12, 1.08, 1.10, 1.22, 1.15, 1.18, 0.90, 0.82, 0.88, 0.78, 0.62, 0.82],
    weight: 0.30,
  },
] as const;

function computeRawScore(data: PatientData, mults: readonly number[]): number {
  const age = parseInt(data.age);
  const bp = parseInt(data.restingBP);
  const chol = parseInt(data.cholesterol);
  const hr = parseInt(data.maxHR);
  const st = parseFloat(data.stDepression);
  const vessels = parseInt(data.numVessels);

  const cpMap: Record<string, number> = { '0': -0.18, '1': 0.08, '2': 0.2, '3': 0.44 };
  const thalMap: Record<string, number> = { '0': -0.1, '1': 0.22, '2': 0.38 };
  const vesselMap: Record<number, number> = { 0: -0.1, 1: 0.16, 2: 0.3, 3: 0.4 };
  const ecgMap: Record<string, number> = { '0': -0.05, '1': 0.14, '2': 0.08 };

  const raws = [
    cpMap[data.chestPain] ?? 0,
    thalMap[data.thal] ?? 0,
    hr < 100 ? 0.38 : hr < 130 ? 0.2 : hr < 150 ? 0.06 : -0.14,
    data.exerciseAngina === '1' ? 0.32 : -0.09,
    vesselMap[vessels] ?? 0,
    st > 3 ? 0.35 : st > 2 ? 0.24 : st > 1 ? 0.14 : st > 0 ? 0.06 : -0.06,
    age > 65 ? 0.32 : age > 55 ? 0.2 : age > 45 ? 0.1 : -0.06,
    chol > 300 ? 0.26 : chol > 240 ? 0.16 : chol > 200 ? 0.06 : -0.04,
    bp > 160 ? 0.24 : bp > 140 ? 0.15 : bp > 120 ? 0.05 : -0.04,
    data.sex === '1' ? 0.16 : -0.1,
    data.fastingBS === '1' ? 0.1 : -0.04,
    ecgMap[data.restingECG] ?? 0,
  ];

  const total = raws.reduce((s, r, i) => s + r * (mults[i] ?? 1), 0);
  // Normalise to [0, 1] using same bounds as predictHeartDisease
  return Math.min(0.97, Math.max(0.03, (total + 0.95) / 4.0));
}

export function computeAllModelPredictions(data: PatientData): PerModelPrediction[] {
  const baselineResults = BASELINE_CONFIGS.map((cfg) => ({
    name: cfg.name,
    shortName: cfg.shortName,
    color: cfg.color,
    isProposed: false,
    probability: computeRawScore(data, cfg.mults),
    ensembleWeight: cfg.weight,
    isHighRisk: false, // set below
  }));

  for (const r of baselineResults) {
    r.isHighRisk = r.probability >= 0.5;
  }

  // Weighted soft-voting ensemble probability
  const ensembleProb = BASELINE_CONFIGS.reduce(
    (s, cfg, i) => s + baselineResults[i].probability * cfg.weight,
    0,
  );

  const ensemble: PerModelPrediction = {
    name: 'Feature-Selected Weighted Soft-Voting Ensemble',
    shortName: 'Ours',
    color: '#0d9488',
    isProposed: true,
    probability: ensembleProb,
    isHighRisk: ensembleProb >= 0.5,
  };

  return [...baselineResults, ensemble];
}

export function savePrediction(result: PredictionResult) {
  sessionStorage.setItem('cardioai_result', JSON.stringify(result));
}

export function loadPrediction(): PredictionResult | null {
  try {
    const raw = sessionStorage.getItem('cardioai_result');
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}
