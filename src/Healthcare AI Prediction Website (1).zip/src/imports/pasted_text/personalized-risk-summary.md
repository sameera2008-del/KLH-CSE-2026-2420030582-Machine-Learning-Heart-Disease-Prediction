Update my existing CardioAI healthcare AI prediction website.

IMPORTANT:
Do NOT redesign the existing website.
Do NOT change the current color palette, typography, navbar, layout style, branding, or existing pages.

The current website has:
Home
Prediction
Results
Explainability
Dashboard
About

The current visual style is a clean, modern healthcare + AI interface with a white background, teal primary color, dark navy headings, rounded cards, subtle borders/shadows, and spacious layouts.

Add TWO NEW FEATURES to the existing website:

==================================================
FEATURE 1: PERSONALIZED RISK SUMMARY
==================================================

Add a new section called:

“Personalized Risk Summary”

This section should appear after the prediction result and should also be accessible from the Results/Explainability area.

PURPOSE:
Convert the technical SHAP and LIME explanations into simple, human-readable insights.

Do NOT show complicated mathematical SHAP/LIME values as the main information.

Create a clean summary card containing:

1. Overall Risk
   Example:
   “High Risk”
   “The model predicts a higher likelihood of heart disease based on the provided clinical information.”

2. Key Risk Factors
   Show the top 3–5 factors that contributed most strongly to the prediction.

   Example:
   • High cholesterol
   • Elevated resting blood pressure
   • Chest pain type
   • Age
   • Maximum heart rate

3. Protective / Lower-Risk Factors
   If applicable, show factors that contributed toward a lower predicted risk.

4. Simple Explanation
   Example:
   “The prediction was mainly influenced by cholesterol level, resting blood pressure, chest pain type, and age.”

5. Explanation Agreement
   Show whether SHAP and LIME identify similar important features.

   Example:
   “SHAP and LIME identified 4 common influential factors.”

Use simple visual indicators such as:
- Red/orange = higher-risk factor
- Green/teal = lower-risk factor
- Neutral gray = normal/less influential factor

Make this section understandable to a healthcare professional who does not have a machine learning background.

==================================================
FEATURE 2: PERSONALIZED RISK FACTOR RECOMMENDATIONS
==================================================

Add a new section called:

“Risk Factor Recommendations”

This should appear below the Personalized Risk Summary.

PURPOSE:
Based on the important risk factors identified by the prediction and explainability layer, provide general health-awareness recommendations.

IMPORTANT SAFETY REQUIREMENT:
This is NOT a medical diagnosis or treatment system.

Do NOT provide:
- medication recommendations
- drug dosages
- disease treatment instructions
- definitive medical advice

Instead, provide safe, general recommendations and encourage consultation with a healthcare professional.

Examples:

If cholesterol is high:
“Consider discussing cholesterol management and appropriate testing with a healthcare professional.”

If resting blood pressure is high:
“Monitor blood pressure regularly and discuss persistent elevated readings with a healthcare professional.”

If exercise-induced angina is present:
“Chest discomfort associated with exercise should be discussed with a qualified healthcare professional.”

If age is a significant contributing factor:
“Age is a non-modifiable risk factor. Regular health screening may be appropriate based on individual medical advice.”

Each recommendation should be presented as a small card:

[Risk Factor Icon]

HIGH CHOLESTEROL
“Identified as an important contributor to the model's prediction.”

Suggested awareness:
“Discuss cholesterol management with a healthcare professional.”

Use a button if appropriate:

“View Explanation”

which takes the user to the corresponding SHAP/LIME explanation.

==================================================
INTEGRATION WITH EXISTING PAGES
==================================================

Do not create unnecessary new pages.

Integrate the new features into the existing flow:

Prediction
    ↓
Prediction Result
    ↓
Personalized Risk Summary
    ↓
SHAP / LIME Explainability
    ↓
Risk Factor Recommendations

The existing navigation should remain:

Home | Prediction | Results | Explainability | Dashboard | About

Optionally add a small navigation link/button called:

“Risk Insights”

but do not replace the existing navigation.

==================================================
RESULT PAGE DESIGN
==================================================

Redesign ONLY the Results page content to accommodate the new features while preserving the existing CardioAI visual identity.

Suggested layout:

------------------------------------------------
HEART DISEASE RISK RESULT

        HIGH RISK
        82% probability

------------------------------------------------
PERSONALIZED RISK SUMMARY

Top contributing factors:
1. Cholesterol
2. Chest Pain
3. Resting Blood Pressure
4. Age
5. Maximum Heart Rate

“Why this prediction?”
Short human-readable explanation.

------------------------------------------------
EXPLAINABILITY

SHAP              LIME
Feature Impact    Patient Explanation

------------------------------------------------
RISK FACTOR RECOMMENDATIONS

[Cholesterol]
General awareness recommendation

[Blood Pressure]
General awareness recommendation

[Chest Pain]
Professional consultation recommendation

------------------------------------------------

DISCLAIMER:
“This system is intended for research and decision-support purposes only.
It does not provide medical diagnosis or replace professional medical advice.”

==================================================
DASHBOARD INTEGRATION
==================================================

Add a small “Risk Insights” section to the existing Dashboard.

Show:

• Most common contributing risk factors
• High-risk vs low-risk predictions
• SHAP/LIME explanation agreement
• Number of patients with major contributing factors

Use clean charts and cards consistent with the existing dashboard.

==================================================
DATA / LOGIC REQUIREMENTS
==================================================

The new features must use the existing prediction result and explanation data.

Do NOT create random or hard-coded patient recommendations.

The logic should be structured so that:

ML Prediction
    ↓
Important Features
    ↓
SHAP/LIME Results
    ↓
Risk Summary
    ↓
Relevant General Recommendations

If the backend/model is not currently connected, create realistic placeholder/mock data and clearly structure the code so that the actual ML prediction, SHAP, and LIME outputs can be connected later.

==================================================
DESIGN REQUIREMENTS
==================================================

Preserve the current CardioAI design.

Use:
- White background
- Teal primary accent
- Dark navy headings
- Rounded cards
- Subtle shadows
- Clean medical icons
- Professional typography
- Spacious layout
- Responsive design
- Clear visual hierarchy

Do NOT:
- Make the site look like a hospital management system
- Add unnecessary animations
- Add excessive gradients
- Overcrowd the Results page
- Use alarming medical language
- Give medical prescriptions

The final user experience should communicate:

“Predict Early.
Understand Better.
Know What Influenced the Prediction.
Understand Your Risk Factors.”

Make the two new features feel like natural extensions of the existing CardioAI website rather than separate modules.