import { NavLink, Outlet, useNavigate } from 'react-router';
import { useState } from 'react';

const navLinks = [
  { to: '/', label: 'Home', end: true },
  { to: '/prediction', label: 'Prediction' },
  { to: '/results', label: 'Results' },
  { to: '/explainability', label: 'Explainability' },
  { to: '/dashboard', label: 'Dashboard' },
  { to: '/comparison', label: 'Comparison' },
  { to: '/about', label: 'About' },
];

function HeartLogo() {
  return (
    <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
      <path d="M12 21.6C6.37 16.06 1 11.3 1 7.2 1 3.41 4.07 2 6.28 2c1.31 0 4.15.5 5.72 4.46C13.59 2.49 16.46 2 17.72 2 20.26 2 23 3.62 23 7.18c0 4.07-5.14 8.63-11 14.42z" />
    </svg>
  );
}

export default function Layout() {
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <header className="bg-white border-b border-slate-200 sticky top-0 z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <NavLink to="/" className="flex items-center gap-2 text-teal-600 font-bold text-lg tracking-tight">
              <HeartLogo />
              <span className="text-slate-800">Cardio<span className="text-teal-600">AI</span></span>
            </NavLink>

            <nav className="hidden lg:flex items-center gap-0.5">
              {navLinks.map((link) => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  end={link.end}
                  className={({ isActive }) =>
                    `px-3.5 py-2 rounded-lg text-sm font-medium transition-colors ${
                      isActive
                        ? 'text-teal-700 bg-teal-50'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`
                  }
                >
                  {link.label}
                </NavLink>
              ))}
            </nav>

            <div className="hidden lg:flex items-center gap-3">
              <button
                onClick={() => navigate('/prediction')}
                className="bg-teal-600 hover:bg-teal-700 active:bg-teal-800 text-white px-4 py-2 rounded-lg text-sm font-semibold transition-colors shadow-sm"
              >
                Start Prediction
              </button>
            </div>

            <button
              className="lg:hidden p-2 rounded-lg text-slate-500 hover:text-slate-700 hover:bg-slate-100 transition-colors"
              onClick={() => setMobileOpen((o) => !o)}
              aria-label="Toggle navigation"
            >
              {mobileOpen ? (
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              ) : (
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              )}
            </button>
          </div>

          {mobileOpen && (
            <nav className="lg:hidden py-3 border-t border-slate-100 flex flex-col gap-0.5 pb-4">
              {navLinks.map((link) => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  end={link.end}
                  onClick={() => setMobileOpen(false)}
                  className={({ isActive }) =>
                    `px-3.5 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                      isActive
                        ? 'text-teal-700 bg-teal-50'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                    }`
                  }
                >
                  {link.label}
                </NavLink>
              ))}
              <button
                onClick={() => { navigate('/prediction'); setMobileOpen(false); }}
                className="mt-2 bg-teal-600 text-white px-3.5 py-2.5 rounded-lg text-sm font-semibold text-left"
              >
                Start Prediction
              </button>
            </nav>
          )}
        </div>
      </header>

      <main className="flex-1">
        <Outlet />
      </main>

      <footer className="bg-white border-t border-slate-200 py-6 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-teal-600">
              <HeartLogo />
              <span className="font-semibold text-slate-800 text-sm">CardioAI</span>
              <span className="text-slate-400 text-sm">· Explainable Heart Disease Prediction</span>
            </div>
            <p className="text-xs text-slate-400 text-center sm:text-right max-w-sm">
              For research and decision-support only. Not a substitute for professional medical advice or diagnosis.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
