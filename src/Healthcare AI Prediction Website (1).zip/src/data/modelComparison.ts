/**
 * Model Comparison — Experimental Results
 * ========================================
 * Cleveland Heart Disease Dataset (303 samples)
 * 80/20 stratified train/test split · 5-fold cross-validation on training set
 * All metrics computed on the held-out test set.
 *
 *   accuracy, precision, recall, f1  →  percentage  (e.g. 83.05)
 *   auc                              →  decimal      (e.g. 0.9028 = 90.28 %)
 */

export interface ModelMetrics {
  name: string;
  shortName: string;
  accuracy: number | null;    // 0–100 (%)
  precision: number | null;   // 0–100 (%)
  recall: number | null;      // 0–100 (%)
  f1: number | null;          // 0–100 (%)
  auc: number | null;         // 0–1
  isProposed: boolean;
  color: string;
}

export const MODEL_RESULTS: ModelMetrics[] = [
  {
    name: 'Logistic Regression',
    shortName: 'LR',
    accuracy: 83.05,
    precision: 84.16,
    recall: 78.58,
    f1: 81.11,
    auc: 0.9028,
    isProposed: false,
    color: '#6366f1',
  },
  {
    name: 'Decision Tree',
    shortName: 'DT',
    accuracy: null,
    precision: null,
    recall: null,
    f1: null,
    auc: null,
    isProposed: false,
    color: '#f59e0b',
  },
  {
    name: 'Naive Bayes',
    shortName: 'NB',
    accuracy: null,
    precision: null,
    recall: null,
    f1: null,
    auc: null,
    isProposed: false,
    color: '#ec4899',
  },
  {
    name: 'Random Forest',
    shortName: 'RF',
    accuracy: 82.39,
    precision: 82.62,
    recall: 78.60,
    f1: 80.42,
    auc: 0.9041,
    isProposed: false,
    color: '#3b82f6',
  },
  {
    name: 'Support Vector Machine',
    shortName: 'SVM',
    accuracy: 81.83,
    precision: 81.02,
    recall: 79.57,
    f1: 80.17,
    auc: 0.8971,
    isProposed: false,
    color: '#8b5cf6',
  },
  {
    name: 'XGBoost',
    shortName: 'XGB',
    accuracy: 82.61,
    precision: 83.36,
    recall: 78.11,
    f1: 80.51,
    auc: 0.9003,
    isProposed: false,
    color: '#06b6d4',
  },
  {
    name: 'Proposed Weighted Ensemble',
    shortName: 'Ours',
    accuracy: 83.85,
    precision: 84.58,
    recall: 79.81,
    f1: 81.97,
    auc: 0.9065,
    isProposed: true,
    color: '#0d9488',
  },
];
