import { createBrowserRouter } from 'react-router';
import Layout from './components/Layout';
import Home from './pages/Home';
import Prediction from './pages/Prediction';
import Results from './pages/Results';
import Explainability from './pages/Explainability';
import Dashboard from './pages/Dashboard';
import ModelComparison from './pages/ModelComparison';
import About from './pages/About';

export const router = createBrowserRouter([
  {
    path: '/',
    Component: Layout,
    children: [
      { index: true, Component: Home },
      { path: 'prediction', Component: Prediction },
      { path: 'results', Component: Results },
      { path: 'explainability', Component: Explainability },
      { path: 'dashboard', Component: Dashboard },
      { path: 'comparison', Component: ModelComparison },
      { path: 'about', Component: About },
    ],
  },
]);
